export interface Product {
  id: string
  name: string
  price: number
  category: "hoodies" | "tees" | "pants" | "accessories"
  description: string
  sizes: string[]
  images: string[]
  featured?: boolean
  newArrival?: boolean
}

export const products: Product[] = [
  {
    id: "1",
    name: "LKF Essential Hoodie",
    price: 120,
    category: "hoodies",
    description: "Premium heavyweight cotton hoodie with embroidered Lowkey Famous logo. Oversized fit with dropped shoulders and ribbed cuffs.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/hoodie-1.jpg"],
    featured: true,
  },
  {
    id: "2",
    name: "Street Dreams Tee",
    price: 55,
    category: "tees",
    description: "100% organic cotton tee with bold graphic print. Relaxed fit with reinforced collar.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/tee-1.jpg"],
    newArrival: true,
  },
  {
    id: "3",
    name: "Night Moves Cargo Pants",
    price: 145,
    category: "pants",
    description: "Technical cargo pants with multiple utility pockets. Adjustable ankle cuffs and elastic waistband.",
    sizes: ["28", "30", "32", "34", "36"],
    images: ["/products/pants-1.jpg"],
    featured: true,
  },
  {
    id: "4",
    name: "Underground Beanie",
    price: 35,
    category: "accessories",
    description: "Ribbed knit beanie with embroidered LKF patch. One size fits all.",
    sizes: ["OS"],
    images: ["/products/beanie-1.jpg"],
    newArrival: true,
  },
  {
    id: "5",
    name: "Midnight Black Hoodie",
    price: 130,
    category: "hoodies",
    description: "All-black heavyweight hoodie with tonal logo embroidery. Double-layered hood and kangaroo pocket.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/hoodie-2.jpg"],
  },
  {
    id: "6",
    name: "Block Letter Tee",
    price: 50,
    category: "tees",
    description: "Vintage wash tee with oversized block letter print. Boxy fit with raw hem details.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/tee-2.jpg"],
    featured: true,
  },
  {
    id: "7",
    name: "Urban Tech Joggers",
    price: 95,
    category: "pants",
    description: "Tapered joggers with zippered pockets. Water-resistant fabric with reflective details.",
    sizes: ["S", "M", "L", "XL"],
    images: ["/products/joggers-1.jpg"],
    newArrival: true,
  },
  {
    id: "8",
    name: "LKF Dad Cap",
    price: 40,
    category: "accessories",
    description: "Washed cotton dad cap with curved brim and embroidered logo. Adjustable strap closure.",
    sizes: ["OS"],
    images: ["/products/cap-1.jpg"],
  },
  {
    id: "9",
    name: "Oversized Logo Hoodie",
    price: 135,
    category: "hoodies",
    description: "Statement hoodie with oversized front logo print. Split kangaroo pocket and extended length.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/hoodie-3.jpg"],
    newArrival: true,
  },
  {
    id: "10",
    name: "Minimal Pocket Tee",
    price: 45,
    category: "tees",
    description: "Clean pocket tee with subtle LKF embroidery. Premium cotton in a classic fit.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    images: ["/products/tee-3.jpg"],
  },
  {
    id: "11",
    name: "Wide Leg Denim",
    price: 160,
    category: "pants",
    description: "Japanese selvedge denim with wide leg silhouette. Raw hem and contrast stitching.",
    sizes: ["28", "30", "32", "34", "36"],
    images: ["/products/denim-1.jpg"],
    featured: true,
  },
  {
    id: "12",
    name: "Chain Link Bracelet",
    price: 65,
    category: "accessories",
    description: "Stainless steel chain link bracelet with LKF tag. Toggle clasp closure.",
    sizes: ["OS"],
    images: ["/products/bracelet-1.jpg"],
  },
]

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id)
}

export function getProductsByCategory(category: Product["category"]): Product[] {
  return products.filter((p) => p.category === category)
}

export function getFeaturedProducts(): Product[] {
  return products.filter((p) => p.featured)
}

export function getNewArrivals(): Product[] {
  return products.filter((p) => p.newArrival)
}
