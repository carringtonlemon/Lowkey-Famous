"use client"

import Link from "next/link"
import type { Product } from "@/lib/products"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/product/${product.id}`} className="group">
      <div className="aspect-[3/4] bg-secondary overflow-hidden relative">
        <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
          <span className="text-6xl font-bold opacity-20 uppercase">{product.name.charAt(0)}</span>
        </div>
        {product.newArrival && (
          <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs font-semibold px-2 py-1 uppercase tracking-wide">
            New
          </span>
        )}
        <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors" />
      </div>
      <div className="mt-4">
        <h3 className="text-sm font-medium group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        <p className="mt-1 text-sm text-muted-foreground">${product.price}</p>
      </div>
    </Link>
  )
}
