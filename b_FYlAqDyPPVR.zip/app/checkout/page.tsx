"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Lock, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/lib/cart-context"

export default function CheckoutPage() {
  const router = useRouter()
  const { items, subtotal, clearCart } = useCart()
  const [isProcessing, setIsProcessing] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  const shipping = subtotal >= 150 ? 0 : 10
  const total = subtotal + shipping

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsProcessing(true)
    
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))
    
    setIsProcessing(false)
    setIsComplete(true)
    clearCart()
  }

  if (items.length === 0 && !isComplete) {
    router.push("/cart")
    return null
  }

  if (isComplete) {
    return (
      <div className="min-h-screen py-12 px-6">
        <div className="max-w-2xl mx-auto text-center py-20">
          <div className="h-16 w-16 rounded-full bg-accent text-accent-foreground mx-auto flex items-center justify-center mb-6">
            <Check className="h-8 w-8" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight uppercase mb-4">
            Order Confirmed
          </h1>
          <p className="text-muted-foreground mb-2">
            Thank you for your order!
          </p>
          <p className="text-muted-foreground mb-8">
            You&apos;ll receive a confirmation email shortly.
          </p>
          <Button asChild size="lg" className="uppercase tracking-wide">
            <Link href="/shop">Continue Shopping</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Back Link */}
        <Link
          href="/cart"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          <span className="text-sm uppercase tracking-wide">Back to Cart</span>
        </Link>

        <h1 className="text-3xl md:text-4xl font-bold tracking-tight uppercase mb-10">
          Checkout
        </h1>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Form Fields */}
            <div className="lg:col-span-2 flex flex-col gap-10">
              {/* Contact */}
              <section>
                <h2 className="text-lg font-semibold uppercase tracking-wide mb-4">
                  Contact
                </h2>
                <input
                  type="email"
                  placeholder="Email address"
                  required
                  className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </section>

              {/* Shipping */}
              <section>
                <h2 className="text-lg font-semibold uppercase tracking-wide mb-4">
                  Shipping Address
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="First name"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="Last name"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="Address"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent md:col-span-2"
                  />
                  <input
                    type="text"
                    placeholder="City"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="ZIP code"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="State"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <input
                    type="text"
                    placeholder="Country"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                </div>
              </section>

              {/* Payment */}
              <section>
                <h2 className="text-lg font-semibold uppercase tracking-wide mb-4">
                  Payment
                </h2>
                <div className="flex flex-col gap-4">
                  <input
                    type="text"
                    placeholder="Card number"
                    required
                    className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="MM / YY"
                      required
                      className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                    <input
                      type="text"
                      placeholder="CVV"
                      required
                      className="w-full bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
                  <Lock className="h-3 w-3" />
                  This is a demo. No payment will be processed.
                </p>
              </section>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-secondary p-6 sticky top-24">
                <h2 className="text-lg font-semibold uppercase tracking-wide mb-6">
                  Order Summary
                </h2>

                {/* Items */}
                <div className="flex flex-col gap-4 mb-6">
                  {items.map((item) => (
                    <div
                      key={`${item.product.id}-${item.size}`}
                      className="flex justify-between text-sm"
                    >
                      <span className="text-muted-foreground">
                        {item.product.name} ({item.size}) x{item.quantity}
                      </span>
                      <span>${item.product.price * item.quantity}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-border pt-4 flex flex-col gap-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>${subtotal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span>{shipping === 0 ? "Free" : `$${shipping}`}</span>
                  </div>
                </div>

                <div className="border-t border-border mt-4 pt-4">
                  <div className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>${total}</span>
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full mt-6 uppercase tracking-wide"
                  disabled={isProcessing}
                >
                  {isProcessing ? "Processing..." : `Pay $${total}`}
                </Button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
