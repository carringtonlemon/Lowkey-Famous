"use client"

import { useSearchParams } from "next/navigation"
import { Suspense } from "react"
import { ProductCard } from "@/components/product-card"
import { products, type Product } from "@/lib/products"
import { cn } from "@/lib/utils"
import Link from "next/link"

const categories = [
  { name: "All", value: null },
  { name: "Hoodies", value: "hoodies" },
  { name: "Tees", value: "tees" },
  { name: "Pants", value: "pants" },
  { name: "Accessories", value: "accessories" },
]

function ShopContent() {
  const searchParams = useSearchParams()
  const category = searchParams.get("category") as Product["category"] | null

  const filteredProducts = category
    ? products.filter((p) => p.category === category)
    : products

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight uppercase">
            {category ? category : "Shop All"}
          </h1>
          <p className="mt-4 text-muted-foreground">
            {filteredProducts.length} {filteredProducts.length === 1 ? "product" : "products"}
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <Link
              key={cat.name}
              href={cat.value ? `/shop?category=${cat.value}` : "/shop"}
              className={cn(
                "px-4 py-2 text-sm font-medium uppercase tracking-wide border transition-colors",
                (category === cat.value || (!category && cat.value === null))
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-transparent border-border hover:border-primary text-muted-foreground hover:text-primary"
              )}
            >
              {cat.name}
            </Link>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-muted-foreground">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function ShopPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen py-12 px-6 flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    }>
      <ShopContent />
    </Suspense>
  )
}
