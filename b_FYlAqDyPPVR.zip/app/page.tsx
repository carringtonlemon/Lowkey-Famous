import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { getFeaturedProducts, getNewArrivals } from "@/lib/products"

export default function HomePage() {
  const featured = getFeaturedProducts()
  const newArrivals = getNewArrivals()

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center bg-secondary">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <p className="text-primary uppercase tracking-[0.3em] text-sm font-medium mb-6">
            New Collection 2026
          </p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight uppercase leading-none text-balance">
            Stay <span className="text-primary">Lowkey</span>.<br />Be <span className="text-accent">Famous</span>.
          </h1>
          <p className="mt-8 text-lg md:text-xl text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Urban streetwear for those who move different. Premium quality meets 
            street culture.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="uppercase tracking-wide">
              <Link href="/shop">
                Shop Collection
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="uppercase tracking-wide">
              <Link href="/shop?category=hoodies">
                View Hoodies
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-primary uppercase tracking-[0.2em] text-sm font-medium mb-2">
                Best Sellers
              </p>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight uppercase">
                Featured
              </h2>
            </div>
            <Link 
              href="/shop" 
              className="text-sm font-medium uppercase tracking-wide hover:text-primary transition-colors flex items-center gap-2"
            >
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="bg-primary text-primary-foreground py-16 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h3 className="text-2xl md:text-3xl font-bold uppercase tracking-tight">
            Free Shipping on Orders Over $150
          </h3>
          <p className="mt-2 text-primary-foreground/80">
            Plus easy returns within 30 days
          </p>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-primary uppercase tracking-[0.2em] text-sm font-medium mb-2">
                Just Dropped
              </p>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight uppercase">
                New Arrivals
              </h2>
            </div>
            <Link 
              href="/shop" 
              className="text-sm font-medium uppercase tracking-wide hover:text-primary transition-colors flex items-center gap-2"
            >
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {newArrivals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 px-6 bg-secondary">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight uppercase text-center mb-12">
            Shop by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Hoodies", href: "/shop?category=hoodies" },
              { name: "Tees", href: "/shop?category=tees" },
              { name: "Pants", href: "/shop?category=pants" },
              { name: "Accessories", href: "/shop?category=accessories" },
            ].map((category) => (
              <Link
                key={category.name}
                href={category.href}
                className="group aspect-square bg-card flex items-center justify-center relative overflow-hidden border border-border hover:border-primary transition-colors"
              >
                <span className="text-lg font-semibold uppercase tracking-wide group-hover:text-primary transition-colors">
                  {category.name}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 px-6">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight uppercase">
            Join the Movement
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Subscribe for exclusive drops, early access, and 10% off your first order.
          </p>
          <form className="mt-8 flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 bg-secondary border border-border px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
            <Button type="submit" className="uppercase tracking-wide">
              Subscribe
            </Button>
          </form>
        </div>
      </section>
    </div>
  )
}
